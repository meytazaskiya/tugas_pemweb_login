<?php
    $nama = $_POST["nama"];
    $usia = $_POST["usia"];
    $npm = $_POST["npm"];
    $alamat = $_POST["alamat"];

    echo "Nama anda adalah " . $nama;
    echo "<br>";
    echo "Usia anda adalah " . $usia;
    echo "<br>";
    echo "NPM anda adalah " . $npm;
    echo "<br>";
    echo "Alamat anda adalah " . $alamat;
?>