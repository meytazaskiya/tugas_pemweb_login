<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" action="tampil.php">
        <label>Masukkan nama</label>
        <input type="text" name="nama">
        <label>Masukkan usia</label>
        <input type="text" name="usia">
        <label>Masukkan NPM</label>
        <input type="text" name="npm">
        <label>Masukkan Alamat</label>
        <input type="text" name="alamat">
        <input type="submit">
</body>
</html>
